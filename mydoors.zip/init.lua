
dofile(minetest.get_modpath("mydoors").."/wood.lua")
dofile(minetest.get_modpath("mydoors").."/locked.lua")
dofile(minetest.get_modpath("mydoors").."/unlocked.lua")


